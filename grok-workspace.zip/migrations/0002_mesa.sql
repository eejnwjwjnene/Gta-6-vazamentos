create table if not exists profiles (
  user_id text primary key,
  handle text not null unique,
  display_name text not null,
  bio text not null default '',
  emoji text not null default '🕵️',
  traits text not null default '[]',
  role text not null default 'membro',
  trust integer not null default 64,
  strikes integer not null default 0,
  needs_setup boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists posts (
  id serial primary key,
  user_id text not null references profiles (user_id),
  kind text not null,
  caption text not null default '',
  media text not null,
  mime text not null,
  status text not null default 'live',
  scam_flags text not null default '[]',
  scam_score integer not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists posts_status_id_idx on posts (status, id desc);
create index if not exists posts_user_idx on posts (user_id, created_at desc);

create table if not exists comments (
  id serial primary key,
  post_id integer not null references posts (id),
  user_id text not null references profiles (user_id),
  body text not null,
  status text not null default 'live',
  scam_flags text not null default '[]',
  scam_score integer not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists comments_post_idx on comments (post_id, id);

create table if not exists reports (
  id serial primary key,
  reporter_id text not null references profiles (user_id),
  target_type text not null,
  target_id text not null,
  reason text not null,
  created_at timestamptz not null default now()
);

create unique index if not exists reports_once_idx on reports (reporter_id, target_type, target_id);
create index if not exists reports_target_idx on reports (target_type, target_id);
