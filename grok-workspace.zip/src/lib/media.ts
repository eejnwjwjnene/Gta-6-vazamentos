export type PreparedMedia = {
  dataUrl: string;
  kind: "image" | "video";
  mime: string;
};

function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ""));
    reader.onerror = () => reject(new Error("Não deu para ler o arquivo."));
    reader.readAsDataURL(file);
  });
}

async function compressImage(file: File): Promise<string> {
  const bitmap = await createImageBitmap(file);
  const maxEdge = 1400;
  const scale = Math.min(1, maxEdge / Math.max(bitmap.width, bitmap.height));
  const width = Math.max(1, Math.round(bitmap.width * scale));
  const height = Math.max(1, Math.round(bitmap.height * scale));
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Não deu para ler a imagem.");
  ctx.drawImage(bitmap, 0, 0, width, height);
  bitmap.close();
  let quality = 0.78;
  let url = canvas.toDataURL("image/jpeg", quality);
  while (url.length > 900_000 && quality > 0.45) {
    quality = Math.round((quality - 0.1) * 100) / 100;
    url = canvas.toDataURL("image/jpeg", quality);
  }
  if (url.length > 1_500_000) throw new Error("Imagem ainda grande demais. Manda um recorte menor.");
  return url;
}

export async function prepareMedia(file: File): Promise<PreparedMedia> {
  if (file.type === "image/gif" && file.size <= 1_200_000) {
    return { dataUrl: await fileToDataUrl(file), kind: "image", mime: "image/gif" };
  }
  if (file.type === "image/svg+xml") {
    throw new Error("SVG não entra. Manda JPG, PNG ou WebP.");
  }
  if (file.type.startsWith("image/")) {
    return { dataUrl: await compressImage(file), kind: "image", mime: "image/jpeg" };
  }
  if (file.type.startsWith("video/")) {
    if (file.size > 1_400_000) {
      throw new Error("Vídeo grande demais. Manda um clipe de até 1,4 MB.");
    }
    const mime = file.type === "video/quicktime" ? "video/quicktime" : file.type;
    return { dataUrl: await fileToDataUrl(file), kind: "video", mime };
  }
  throw new Error("Só imagem ou vídeo.");
}
