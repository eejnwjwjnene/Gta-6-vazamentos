export const MARKS = [
  { id: "olho", emoji: "🕵️", label: "Olho da rua" },
  { id: "lente", emoji: "📸", label: "Lente" },
  { id: "claquete", emoji: "🎬", label: "Claquete" },
  { id: "mapa", emoji: "🗺️", label: "Mapa" },
  { id: "escudo", emoji: "🛡️", label: "Escudo" },
  { id: "sinal", emoji: "📡", label: "Sinal" },
  { id: "noite", emoji: "🌙", label: "Noite" },
  { id: "volante", emoji: "🚗", label: "Volante" },
  { id: "joia", emoji: "💎", label: "Joia" },
  { id: "raposa", emoji: "🦊", label: "Raposa" },
  { id: "alvo", emoji: "🎯", label: "Alvo" },
  { id: "fogo", emoji: "🔥", label: "Fogo" },
] as const;

export const TRAITS = [
  { id: "investigador", label: "Investigador" },
  { id: "olheiro", label: "Olheiro" },
  { id: "arquivo", label: "Arquivista" },
  { id: "sentinela", label: "Sentinela" },
  { id: "corredor", label: "Corredor" },
  { id: "noturno", label: "Noturno" },
  { id: "cartografo", label: "Cartógrafo" },
  { id: "rumor", label: "Caçador de rumor" },
] as const;

export const REPORT_REASONS = [
  "Golpe ou Pix",
  "Arquivo suspeito",
  "Conta falsa",
  "Conteúdo roubado",
] as const;

export type RadarHit = { code: string; label: string; weight: number };

const RULES: { code: string; label: string; weight: number; pattern: string; flags: string }[] = [
  { code: "pix", label: "pedido de Pix", weight: 50, pattern: "(chave\\s*pix|meu\\s+pix|manda(r)?\\s+(o\\s+)?pix|paga(r)?\\s+(no\\s+)?pix|pix\\s*[:\\-]|copia\\s*e\\s*cola)", flags: "i" },
  { code: "pagamento", label: "cobrança", weight: 40, pattern: "(pague\\s+para|pagamento\\s+adiant|dep[oó]sito|paypal|picpay|boleto|r\\$\\s*\\d|\\busdt\\b|binance)", flags: "i" },
  { code: "early", label: "early access pago", weight: 48, pattern: "(early\\s*access|acesso\\s+antecipado|compre\\s+o\\s+(jogo|vazamento)|vazamento\\s+pago)", flags: "i" },
  { code: "arquivo", label: "arquivo executável", weight: 55, pattern: "(\\.(exe|apk|bat|scr|msi)\\b|baixe\\s+o\\s+(apk|jogo|arquivo)|mediafire|mega\\.nz)", flags: "i" },
  { code: "encurtador", label: "link encurtado", weight: 28, pattern: "(bit\\.ly|tinyurl|t\\.co/|encurtador|linktr\\.ee)", flags: "i" },
  { code: "credencial", label: "pedido de senha ou cartão", weight: 60, pattern: "(social\\s*club|senha\\s+da\\s+(rockstar|conta)|manda(r)?\\s+(sua\\s+)?senha|dados\\s+do\\s+cart|n[uú]mero\\s+do\\s+cart|\\bcvv\\b)", flags: "i" },
  { code: "grupo", label: "grupo VIP pago", weight: 36, pattern: "(grupo\\s+vip|(whats\\s*app|telegram|discord).{0,32}(pago|pix|r\\$))", flags: "i" },
  { code: "phishing", label: "isca de conta", weight: 58, pattern: "(roub(ar|o)\\s+de\\s+conta|hacke(ar|ie)|gerador\\s+de\\s+(key|conta)|conta\\s+de\\s+gra[cç]a|login\\s+da\\s+rockstar)", flags: "i" },
];

export const RADAR_LEGEND = RULES.map((rule) => rule.label);

export function scanRadar(text: string): { score: number; hits: RadarHit[] } {
  const hits: RadarHit[] = [];
  for (const rule of RULES) {
    if (new RegExp(rule.pattern, rule.flags).test(text)) {
      hits.push({ code: rule.code, label: rule.label, weight: rule.weight });
    }
  }
  const score = Math.min(100, hits.reduce((sum, hit) => sum + hit.weight, 0));
  return { score, hits };
}

export function radarVerdict(score: number): "limpo" | "suspeito" | "quarentena" {
  if (score >= 45) return "quarentena";
  if (score >= 20) return "suspeito";
  return "limpo";
}

export function traitLabel(id: string): string {
  return TRAITS.find((trait) => trait.id === id)?.label ?? id;
}

export function isMark(emoji: string): boolean {
  return MARKS.some((mark) => mark.emoji === emoji);
}

export function isTrait(id: string): boolean {
  return TRAITS.some((trait) => trait.id === id);
}
