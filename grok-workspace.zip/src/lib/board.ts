import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { authMiddleware } from "@/lib/auth/middleware";
import { isMark, isTrait, scanRadar } from "@/lib/marks";

export type Me = {
  handle: string;
  displayName: string;
  bio: string;
  emoji: string;
  traits: string[];
  role: "admin" | "membro" | "banido";
  trust: number;
  strikes: number;
  needsSetup: boolean;
};

export type Author = {
  handle: string;
  displayName: string;
  emoji: string;
  traits: string[];
  trust: number;
  admin: boolean;
};

export type FeedPost = {
  id: number;
  kind: "image" | "video";
  caption: string;
  media: string;
  mime: string;
  status: "live" | "held";
  score: number;
  flags: string[];
  createdAt: string;
  commentCount: number;
  mine: boolean;
  author: Author;
};

export type DeskStats = {
  live: number;
  held: number;
  removed: number;
  members: number;
  heldNotes: number;
};

export type ThreadComment = {
  id: number;
  body: string;
  createdAt: string;
  status: "live" | "held";
  flags: string[];
  mine: boolean;
  author: Pick<Author, "handle" | "displayName" | "emoji" | "admin">;
};

export type MemberRow = {
  userId: string;
  handle: string;
  displayName: string;
  emoji: string;
  role: Me["role"];
  trust: number;
  strikes: number;
};

export type ReportRow = {
  id: number;
  targetType: "post" | "comment";
  targetId: string;
  reason: string;
  createdAt: string;
  reporterHandle: string;
};

const IMAGE_MIME = ["image/jpeg", "image/png", "image/webp", "image/gif"] as const;
const VIDEO_MIME = ["video/mp4", "video/webm", "video/quicktime"] as const;
const RESERVED = new Set(["admin", "radar", "sistema", "suporte"]);

const profileSchema = z.object({
  handle: z.string(),
  displayName: z.string(),
  bio: z.string(),
  emoji: z.string(),
  traits: z.array(z.string()),
});

const publishSchema = z.object({
  caption: z.string(),
  media: z.string(),
  mime: z.string(),
  kind: z.enum(["image", "video"]),
});

const commentSchema = z.object({
  postId: z.number(),
  body: z.string(),
});

const reportSchema = z.object({
  targetType: z.enum(["post", "comment"]),
  targetId: z.number(),
  reason: z.string(),
});

const moderateSchema = z.discriminatedUnion("action", [
  z.object({ action: z.literal("release"), postId: z.number() }),
  z.object({ action: z.literal("remove"), postId: z.number() }),
  z.object({ action: z.literal("ban"), userId: z.string() }),
  z.object({ action: z.literal("unban"), userId: z.string() }),
  z.object({ action: z.literal("dismiss"), reportId: z.number() }),
]);

type ProfileRow = {
  user_id: string;
  handle: string;
  display_name: string;
  bio: string;
  emoji: string;
  traits: string;
  role: string;
  trust: number;
  strikes: number;
  needs_setup: boolean;
};

type PostRow = {
  id: number;
  user_id: string;
  kind: string;
  caption: string;
  media: string;
  mime: string;
  status: string;
  scam_flags: string;
  scam_score: number;
  created_at: string | Date;
  handle: string;
  display_name: string;
  emoji: string;
  traits: string;
  role: string;
  trust: number;
  comment_count: number;
};

function stamp(value: unknown): string {
  if (value instanceof Date) return value.toISOString();
  return String(value ?? "");
}

function parseList(value: string): string[] {
  try {
    const parsed = JSON.parse(value) as unknown;
    return Array.isArray(parsed) ? parsed.filter((item) => typeof item === "string") : [];
  } catch {
    return [];
  }
}

function asRole(value: string): Me["role"] {
  if (value === "admin" || value === "banido") return value;
  return "membro";
}

function asBool(value: unknown): boolean {
  return value === true || value === "t" || value === "true" || value === 1;
}

function toMe(row: ProfileRow): Me {
  return {
    handle: row.handle,
    displayName: row.display_name,
    bio: row.bio,
    emoji: row.emoji,
    traits: parseList(row.traits),
    role: asRole(row.role),
    trust: Number(row.trust),
    strikes: Number(row.strikes),
    needsSetup: asBool(row.needs_setup),
  };
}

function cleanText(value: string, max: number): string {
  return value.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "").trim().slice(0, max);
}

function isUnique(error: unknown): boolean {
  const message = error instanceof Error ? error.message : String(error);
  const code = typeof error === "object" && error && "code" in error ? String((error as { code: unknown }).code) : "";
  return code === "23505" || /unique|duplicate/i.test(message);
}

function seedHandle(userId: string, pass: number): string {
  const tail = userId.replace(/[^a-z0-9]/gi, "").toLowerCase().slice(-4) || "0000";
  return `agente${tail}${pass === 0 ? "" : pass}`.slice(0, 16);
}

async function db() {
  const { getSql } = await import("@/lib/db");
  return getSql();
}

async function readProfile(userId: string): Promise<ProfileRow | null> {
  const sql = await db();
  const rows = await sql<ProfileRow>`select user_id, handle, display_name, bio, emoji, traits, role, trust, strikes, needs_setup from profiles where user_id = ${userId} limit 1`;
  return rows[0] ?? null;
}

async function ensureProfile(userId: string, suggestedName: string): Promise<ProfileRow> {
  const existing = await readProfile(userId);
  if (existing) return existing;
  const sql = await db();
  const displayName = cleanText(suggestedName, 32) || "Agente";
  for (let pass = 0; pass < 6; pass += 1) {
    const handle = seedHandle(userId, pass);
    try {
      await sql`
        insert into profiles (user_id, handle, display_name, emoji, role)
        select ${userId}, ${handle}, ${displayName}, ${"🕵️"},
          case when exists (select 1 from profiles where role = 'admin') then 'membro' else 'admin' end
        where not exists (select 1 from profiles where user_id = ${userId})
      `;
      break;
    } catch (error) {
      if (!isUnique(error) || pass === 5) throw error;
    }
  }
  const created = await readProfile(userId);
  if (!created) throw new Error("Não deu para abrir seu perfil.");
  return created;
}

function mapPost(row: PostRow, userId: string, known: Set<number>): FeedPost {
  const status = row.status === "held" ? "held" : "live";
  return {
    id: Number(row.id),
    kind: row.kind === "video" ? "video" : "image",
    caption: row.caption,
    media: known.has(Number(row.id)) ? "" : row.media,
    mime: row.mime,
    status,
    score: Number(row.scam_score),
    flags: parseList(row.scam_flags),
    createdAt: stamp(row.created_at),
    commentCount: Number(row.comment_count),
    mine: row.user_id === userId,
    author: {
      handle: row.handle,
      displayName: row.display_name,
      emoji: row.emoji,
      traits: parseList(row.traits),
      trust: Number(row.trust),
      admin: row.role === "admin",
    },
  };
}

async function fetchFeed(userId: string, isAdmin: boolean, known: Set<number>): Promise<FeedPost[]> {
  const sql = await db();
  const rows = await sql<PostRow>`
    select p.id, p.user_id, p.kind, p.caption, p.media, p.mime, p.status, p.scam_flags, p.scam_score, p.created_at,
           pr.handle, pr.display_name, pr.emoji, pr.traits, pr.role, pr.trust,
           (select count(*)::int from comments c where c.post_id = p.id and (c.status = 'live' or (c.status = 'held' and (c.user_id = ${userId} or ${isAdmin})))) as comment_count
    from posts p
    join profiles pr on pr.user_id = p.user_id
    where p.status = 'live'
       or (p.status = 'held' and (p.user_id = ${userId} or ${isAdmin}))
    order by p.id desc
    limit 12
  `;
  return rows.map((row) => mapPost(row, userId, known));
}

async function fetchStats(): Promise<DeskStats> {
  const sql = await db();
  const rows = await sql<{ live: number; held: number; removed: number; members: number; held_notes: number }>`
    select
      (select count(*)::int from posts where status = 'live') as live,
      (select count(*)::int from posts where status = 'held') as held,
      (select count(*)::int from posts where status = 'removed') as removed,
      (select count(*)::int from profiles) as members,
      (select count(*)::int from comments where status = 'held') as held_notes
  `;
  const row = rows[0];
  return {
    live: Number(row?.live ?? 0),
    held: Number(row?.held ?? 0),
    removed: Number(row?.removed ?? 0),
    members: Number(row?.members ?? 0),
    heldNotes: Number(row?.held_notes ?? 0),
  };
}

function assertMedia(media: string, mime: string, kind: "image" | "video") {
  if (media.length > 1_600_000) throw new Error("Arquivo grande demais.");
  if (!media.startsWith(`data:${mime};base64,`)) throw new Error("Mídia inválida.");
  const allowed: readonly string[] = kind === "image" ? IMAGE_MIME : VIDEO_MIME;
  if (!allowed.includes(mime)) throw new Error("Esse formato não entra.");
}

async function shiftTrust(userId: string, delta: number, strike: number) {
  const sql = await db();
  await sql`
    update profiles
    set trust = least(100, greatest(0, trust + ${delta})),
        strikes = greatest(0, strikes + ${strike})
    where user_id = ${userId}
  `;
  if (strike > 0) {
    await sql`
      update profiles
      set role = 'banido'
      where user_id = ${userId} and role <> 'admin' and strikes >= 5
    `;
  }
}

const deskInput = z.object({
  knownIds: z.array(z.number()).optional(),
  suggestedName: z.string().optional(),
});

export const loadDesk = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => deskInput.parse(input ?? {}))
  .handler(async ({ context, data }) => {
    const profile = await ensureProfile(context.userId, data.suggestedName ?? "");
    const me = toMe(profile);
    const known = new Set((data.knownIds ?? []).filter((id) => Number.isInteger(id) && id > 0).slice(0, 40));
    const [posts, stats] = await Promise.all([
      fetchFeed(context.userId, me.role === "admin", known),
      fetchStats(),
    ]);
    return { me, posts, stats };
  });

export const saveProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => profileSchema.parse(input))
  .handler(async ({ context, data }) => {
    const handle = data.handle.trim().toLowerCase();
    const displayName = cleanText(data.displayName, 32);
    const bio = cleanText(data.bio, 160);
    const traits = [...new Set(data.traits.filter(isTrait))].slice(0, 3);
    if (!/^[a-z0-9_]{3,16}$/.test(handle) || RESERVED.has(handle)) {
      return { ok: false as const, error: "Arroba de 3 a 16 letras, números ou _." };
    }
    if (displayName.length < 2) return { ok: false as const, error: "Nome precisa de pelo menos 2 letras." };
    if (!isMark(data.emoji)) return { ok: false as const, error: "Escolhe um emblema da mesa." };
    const current = await readProfile(context.userId);
    if (!current) return { ok: false as const, error: "Perfil ainda não existe." };
    if (current.role === "banido") return { ok: false as const, error: "Conta bloqueada pelo radar." };
    const sql = await db();
    const taken = await sql<{ user_id: string }>`select user_id from profiles where handle = ${handle} and user_id <> ${context.userId} limit 1`;
    if (taken.length) return { ok: false as const, error: "Esse arroba já está na mesa." };
    await sql`
      update profiles
      set handle = ${handle},
          display_name = ${displayName},
          bio = ${bio},
          emoji = ${data.emoji},
          traits = ${JSON.stringify(traits)},
          needs_setup = false
      where user_id = ${context.userId}
    `;
    const next = await readProfile(context.userId);
    if (!next) return { ok: false as const, error: "Não deu para salvar." };
    return { ok: true as const, me: toMe(next) };
  });

export const publishPost = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => publishSchema.parse(input))
  .handler(async ({ context, data }) => {
    const profile = await readProfile(context.userId);
    if (!profile) return { ok: false as const, error: "Monta teu perfil antes de publicar." };
    if (profile.role === "banido") return { ok: false as const, error: "Conta bloqueada pelo radar." };
    if (profile.needs_setup) return { ok: false as const, error: "Termina teu perfil antes de publicar." };
    const caption = cleanText(data.caption, 280);
    try {
      assertMedia(data.media, data.mime, data.kind);
    } catch (error) {
      return { ok: false as const, error: error instanceof Error ? error.message : "Mídia inválida." };
    }
    const sql = await db();
    const recent = await sql<{ n: number }>`
      select count(*)::int as n from posts
      where user_id = ${context.userId} and created_at > now() - interval '10 minutes'
    `;
    if (Number(recent[0]?.n ?? 0) >= 6) {
      return { ok: false as const, error: "Calma. O radar limita a 6 publicações a cada 10 minutos." };
    }
    const radar = scanRadar(caption);
    const held = radar.score >= 45;
    const rows = await sql<{ id: number }>`
      insert into posts (user_id, kind, caption, media, mime, status, scam_flags, scam_score)
      values (
        ${context.userId},
        ${data.kind},
        ${caption},
        ${data.media},
        ${data.mime},
        ${held ? "held" : "live"},
        ${JSON.stringify(radar.hits.map((hit) => hit.label))},
        ${radar.score}
      )
      returning id
    `;
    const id = Number(rows[0]?.id);
    await shiftTrust(context.userId, held ? -12 : radar.score >= 20 ? 0 : 2, held ? 1 : 0);
    const feed = await fetchFeed(context.userId, profile.role === "admin", new Set());
    const post = feed.find((item) => item.id === id) ?? null;
    return {
      ok: true as const,
      held,
      flags: radar.hits.map((hit) => hit.label),
      post,
    };
  });

export const removeOwn = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => z.object({ postId: z.number() }).parse(input))
  .handler(async ({ context, data }) => {
    const postId = data.postId;
    if (!Number.isInteger(postId) || postId < 1) return { ok: false as const, error: "Post inválido." };
    const sql = await db();
    const rows = await sql<{ id: number }>`
      update posts set status = 'removed', media = ''
      where id = ${postId} and user_id = ${context.userId} and status <> 'removed'
      returning id
    `;
    if (!rows.length) return { ok: false as const, error: "Não achei esse vazamento seu." };
    return { ok: true as const };
  });

async function visiblePost(postId: number, userId: string, isAdmin: boolean) {
  const sql = await db();
  const rows = await sql<{ id: number; user_id: string; status: string }>`
    select id, user_id, status from posts where id = ${postId} limit 1
  `;
  const post = rows[0];
  if (!post || post.status === "removed") return null;
  if (post.status === "held" && post.user_id !== userId && !isAdmin) return null;
  return post;
}

export const loadThread = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => z.object({ postId: z.number() }).parse(input))
  .handler(async ({ context, data }) => {
    const profile = await readProfile(context.userId);
    if (!profile) return { comments: [] as ThreadComment[] };
    const isAdmin = profile.role === "admin";
    const post = await visiblePost(data.postId, context.userId, isAdmin);
    if (!post) return { comments: [] as ThreadComment[] };
    const sql = await db();
    const rows = await sql<{
      id: number;
      body: string;
      status: string;
      scam_flags: string;
      created_at: string | Date;
      user_id: string;
      handle: string;
      display_name: string;
      emoji: string;
      role: string;
    }>`
      select c.id, c.body, c.status, c.scam_flags, c.created_at, c.user_id,
             pr.handle, pr.display_name, pr.emoji, pr.role
      from comments c
      join profiles pr on pr.user_id = c.user_id
      where c.post_id = ${data.postId}
        and c.status <> 'removed'
        and (c.status = 'live' or c.user_id = ${context.userId} or ${isAdmin})
      order by c.id asc
      limit 200
    `;
    const comments: ThreadComment[] = rows.map((row) => ({
      id: Number(row.id),
      body: row.body,
      createdAt: stamp(row.created_at),
      status: row.status === "held" ? "held" : "live",
      flags: parseList(row.scam_flags),
      mine: row.user_id === context.userId,
      author: {
        handle: row.handle,
        displayName: row.display_name,
        emoji: row.emoji,
        admin: row.role === "admin",
      },
    }));
    return { comments };
  });

export const addComment = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => commentSchema.parse(input))
  .handler(async ({ context, data }) => {
    const profile = await readProfile(context.userId);
    if (!profile) return { ok: false as const, error: "Monta teu perfil para comentar." };
    if (profile.role === "banido") return { ok: false as const, error: "Conta bloqueada pelo radar." };
    if (profile.needs_setup) return { ok: false as const, error: "Termina teu perfil para comentar." };
    const body = cleanText(data.body, 400);
    if (body.length < 1) return { ok: false as const, error: "Escreve um comentário." };
    const isAdmin = profile.role === "admin";
    const post = await visiblePost(data.postId, context.userId, isAdmin);
    if (!post) return { ok: false as const, error: "Esse vazamento não está no ar." };
    const sql = await db();
    const recent = await sql<{ n: number }>`
      select count(*)::int as n from comments
      where user_id = ${context.userId} and created_at > now() - interval '5 minutes'
    `;
    if (Number(recent[0]?.n ?? 0) >= 15) {
      return { ok: false as const, error: "Calma nos comentários. O radar segurou o ritmo." };
    }
    const radar = scanRadar(body);
    const held = radar.score >= 45;
    await sql`
      insert into comments (post_id, user_id, body, status, scam_flags, scam_score)
      values (
        ${data.postId},
        ${context.userId},
        ${body},
        ${held ? "held" : "live"},
        ${JSON.stringify(radar.hits.map((hit) => hit.label))},
        ${radar.score}
      )
    `;
    if (held) await shiftTrust(context.userId, -4, 0);
    return { ok: true as const, held, flags: radar.hits.map((hit) => hit.label) };
  });

export const reportTarget = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => reportSchema.parse(input))
  .handler(async ({ context, data }) => {
    const profile = await readProfile(context.userId);
    if (!profile || profile.role === "banido") return { ok: false as const, error: "Não deu para denunciar." };
    const reason = cleanText(data.reason, 180);
    if (reason.length < 3) return { ok: false as const, error: "Diz o motivo da denúncia." };
    const targetId = String(data.targetId);
    const sql = await db();
    try {
      await sql`
        insert into reports (reporter_id, target_type, target_id, reason)
        values (${context.userId}, ${data.targetType}, ${targetId}, ${reason})
      `;
    } catch (error) {
      if (isUnique(error)) return { ok: true as const, queued: false, duplicate: true };
      throw error;
    }
    const counts = await sql<{ n: number }>`
      select count(*)::int as n from reports where target_type = ${data.targetType} and target_id = ${targetId}
    `;
    let queued = false;
    if (Number(counts[0]?.n ?? 0) >= 3 && data.targetType === "post") {
      const updated = await sql<{ id: number }>`
        update posts set status = 'held', scam_score = greatest(scam_score, 45),
          scam_flags = ${JSON.stringify(["várias denúncias"])}
        where id = ${data.targetId} and status = 'live'
        returning id
      `;
      queued = updated.length > 0;
    }
    return { ok: true as const, queued, duplicate: false };
  });

export const loadCentral = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => z.object({ knownIds: z.array(z.number()).optional() }).parse(input ?? {}))
  .handler(async ({ context, data }) => {
    const profile = await readProfile(context.userId);
    if (!profile || profile.role !== "admin") return { ok: false as const, error: "Só o admin entra na central." };
    const sql = await db();
    const known = new Set((data.knownIds ?? []).filter((id) => Number.isInteger(id) && id > 0));
    const heldRows = await sql<PostRow>`
      select p.id, p.user_id, p.kind, p.caption, p.media, p.mime, p.status, p.scam_flags, p.scam_score, p.created_at,
             pr.handle, pr.display_name, pr.emoji, pr.traits, pr.role, pr.trust,
             (select count(*)::int from comments c where c.post_id = p.id and c.status <> 'removed') as comment_count
      from posts p
      join profiles pr on pr.user_id = p.user_id
      where p.status = 'held'
      order by p.id desc
      limit 20
    `;
    const reports = await sql<{
      id: number;
      target_type: string;
      target_id: string;
      reason: string;
      created_at: string | Date;
      handle: string;
    }>`
      select r.id, r.target_type, r.target_id, r.reason, r.created_at, pr.handle
      from reports r
      join profiles pr on pr.user_id = r.reporter_id
      order by r.id desc
      limit 40
    `;
    const members = await sql<{
      user_id: string;
      handle: string;
      display_name: string;
      emoji: string;
      role: string;
      trust: number;
      strikes: number;
    }>`
      select user_id, handle, display_name, emoji, role, trust, strikes
      from profiles
      order by created_at asc
      limit 100
    `;
    return {
      ok: true as const,
      held: heldRows.map((row) => mapPost(row, context.userId, known)),
      reports: reports.map((row) => ({
        id: Number(row.id),
        targetType: row.target_type === "comment" ? "comment" as const : "post" as const,
        targetId: row.target_id,
        reason: row.reason,
        createdAt: stamp(row.created_at),
        reporterHandle: row.handle,
      })),
      members: members.map((row) => ({
        userId: row.user_id,
        handle: row.handle,
        displayName: row.display_name,
        emoji: row.emoji,
        role: asRole(row.role),
        trust: Number(row.trust),
        strikes: Number(row.strikes),
      })),
    };
  });

export const moderate = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => moderateSchema.parse(input))
  .handler(async ({ context, data }) => {
    const profile = await readProfile(context.userId);
    if (!profile || profile.role !== "admin") return { ok: false as const, error: "Só o admin mexe na central." };
    const sql = await db();
    if (data.action === "release") {
      await sql`
        update posts set status = 'live', scam_score = 0, scam_flags = '[]'
        where id = ${data.postId} and status = 'held'
      `;
      return { ok: true as const };
    }
    if (data.action === "remove") {
      await sql`
        update posts set status = 'removed', media = ''
        where id = ${data.postId} and status <> 'removed'
      `;
      return { ok: true as const };
    }
    if (data.action === "dismiss") {
      await sql`delete from reports where id = ${data.reportId}`;
      return { ok: true as const };
    }
    if (data.userId === context.userId) return { ok: false as const, error: "Você não bloqueia a própria conta." };
    if (data.action === "ban") {
      const updated = await sql<{ user_id: string }>`
        update profiles set role = 'banido'
        where user_id = ${data.userId} and role = 'membro'
        returning user_id
      `;
      if (!updated.length) return { ok: false as const, error: "Esse agente não pode ser bloqueado." };
      return { ok: true as const };
    }
    await sql`
      update profiles set role = 'membro', strikes = 0, trust = greatest(trust, 40)
      where user_id = ${data.userId} and role = 'banido'
    `;
    return { ok: true as const };
  });
