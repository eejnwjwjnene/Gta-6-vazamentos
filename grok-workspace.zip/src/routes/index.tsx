import { createFileRoute } from "@tanstack/react-router";
import { NightBackdrop } from "@/components/night";
import { Mesa } from "@/components/mesa";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <>
      <NightBackdrop />
      <Mesa />
    </>
  );
}
