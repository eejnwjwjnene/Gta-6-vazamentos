import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useSyncExternalStore } from "react";
import { NightBackdrop } from "@/components/night";
import { SignInActions } from "@/components/sign-in-actions";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/login")({ component: Login });

function useMounted() {
  return useSyncExternalStore(
    () => () => {},
    () => true,
    () => false,
  );
}

function Login() {
  const mounted = useMounted();
  const { user, isPending } = useCurrentUserState();
  if (mounted && !isPending && user) return <Navigate to="/" />;

  return (
    <>
      <NightBackdrop />
      <main className="relative z-10 mx-auto flex min-h-dvh max-w-lg flex-col justify-center px-4 py-10">
        <p className="text-xs font-semibold uppercase tracking-widest text-cyan">Mesa noturna</p>
        <h1 className="mt-2 font-display text-5xl uppercase leading-none text-fg">Entrar na mesa</h1>
        <p className="mt-3 text-pretty text-muted">
          Google ou X. Quem abre a mesa pela primeira vez vira administrador do radar.
        </p>
        <div className="mt-6">
          {mounted && !isPending && !user ? <SignInActions /> : <div className="h-11" />}
        </div>
      </main>
    </>
  );
}
