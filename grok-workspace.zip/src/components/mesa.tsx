import * as Dialog from "@radix-ui/react-dialog";
import {
  BadgeCheck,
  Film,
  ImagePlus,
  Lock,
  MessageCircle,
  Radio,
  Send,
  Shield,
  Siren,
  Trash2,
  X,
} from "lucide-react";
import { useCallback, useEffect, useRef, useState, useSyncExternalStore, type ReactNode } from "react";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import {
  addComment,
  loadCentral,
  loadDesk,
  loadThread,
  moderate,
  publishPost,
  removeOwn,
  reportTarget,
  saveProfile,
  type DeskStats,
  type FeedPost,
  type Me,
  type MemberRow,
  type ReportRow,
  type ThreadComment,
} from "@/lib/board";
import { MARKS, RADAR_LEGEND, REPORT_REASONS, scanRadar, traitLabel, TRAITS } from "@/lib/marks";
import { prepareMedia } from "@/lib/media";
import { SignInActions } from "@/components/sign-in-actions";

function useMounted() {
  return useSyncExternalStore(
    () => () => {},
    () => true,
    () => false,
  );
}

function errText(error: unknown): string {
  if (error instanceof Error && error.message) return error.message;
  if (typeof error === "object" && error && "message" in error && typeof error.message === "string") {
    return error.message;
  }
  return "Não deu. Tenta de novo.";
}

function ago(iso: string): string {
  const then = new Date(iso).getTime();
  if (!Number.isFinite(then)) return "";
  const seconds = Math.max(0, Math.round((Date.now() - then) / 1000));
  if (seconds < 10) return "agora";
  if (seconds < 60) return `há ${seconds}s`;
  const minutes = Math.round(seconds / 60);
  if (minutes < 60) return `há ${minutes} min`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `há ${hours} h`;
  return `há ${Math.round(hours / 24)} d`;
}

function caseNo(id: number): string {
  return `VAZ-${String(id).padStart(3, "0")}`;
}

const field =
  "w-full rounded-2xl border border-line bg-bg/80 px-3 py-3 text-sm text-fg outline-none transition-colors duration-200 focus-visible:border-primary";
const primaryBtn =
  "inline-flex min-h-11 cursor-pointer items-center justify-center gap-2 rounded-full bg-primary px-4 text-sm font-semibold text-primary-fg transition-colors duration-200 hover:bg-primary/90 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary disabled:opacity-50";
const ghostBtn =
  "inline-flex min-h-11 cursor-pointer items-center justify-center gap-2 rounded-full border border-line bg-surface/80 px-4 text-sm font-semibold text-fg transition-colors duration-200 hover:border-primary/70 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary disabled:opacity-50";

function Brand() {
  return (
    <div className="flex items-center gap-3">
      <img src="/media/logo.png" alt="" className="h-14 w-12 rounded-xl object-cover" />
      <div>
        <p className="font-display text-2xl uppercase leading-none tracking-wide text-fg">Vazamentos</p>
        <p className="text-xs font-semibold uppercase tracking-widest text-primary">GTA 6</p>
      </div>
    </div>
  );
}

function LivePill({ label }: { label: string }) {
  return (
    <span className="inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-surface/80 px-3 text-xs font-semibold uppercase tracking-widest text-cyan">
      <span className="live-dot h-2 w-2 rounded-full bg-cyan" aria-hidden="true" />
      {label}
    </span>
  );
}

export function Mesa() {
  const mounted = useMounted();
  const { user, isPending } = useCurrentUserState();
  const signedIn = mounted && !isPending && !!user;

  return (
    <div className="relative z-10 mx-auto min-h-dvh max-w-5xl px-4 pb-16 pt-4">
      <header className="flex items-center justify-between gap-3">
        <Brand />
        {!signedIn && <LivePill label="Radar ativo" />}
      </header>
      {signedIn && user ? (
        <Desk suggestedName={user.displayName ?? ""} />
      ) : (
        <Guest showActions={mounted && !isPending && !user} />
      )}
    </div>
  );
}

function Guest({ showActions }: { showActions: boolean }) {
  return (
    <div className="mt-8 md:mt-14">
      <div className="grid items-center gap-8 md:grid-cols-[1.15fr_0.85fr]">
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest text-cyan">Los Santos depois da meia-noite</p>
          <h1 className="mt-3 font-display text-5xl uppercase leading-none text-fg md:text-7xl">
            A mesa dos vazamentos
          </h1>
          <p className="mt-4 max-w-xl text-pretty text-muted">
            Entra, monta um perfil com emblema e características, e publica imagem ou vídeo.
            Os comentários aparecem para todo mundo na hora. O radar anti-roubo segura Pix, senha, arquivo suspeito e early access pago.
          </p>
          <div className="mt-6 min-h-11">{showActions ? <SignInActions /> : null}</div>
          <p className="mt-4 max-w-md text-sm text-muted">
            Mesa de fãs. Não é a Rockstar. Nunca pague por vazamento e nunca entregue sua conta.
          </p>
        </div>
        <img
          src="/media/logo.png"
          alt="Selo Vazamentos GTA 6"
          className="mx-auto w-full max-w-sm rounded-3xl border border-line shadow-2xl"
        />
      </div>
      <section className="mt-10 grid gap-3 md:grid-cols-3">
        <InfoCard icon={<Shield className="size-5" aria-hidden="true" />} title="Radar anti-roubo" body="Cada post e comentário passa no radar antes de ir para a mesa. Golpe cai na quarentena." />
        <InfoCard icon={<Radio className="size-5" aria-hidden="true" />} title="Ao vivo" body="Comentário novo chega sozinho para quem está olhando o mesmo vazamento." />
        <InfoCard icon={<BadgeCheck className="size-5" aria-hidden="true" />} title="Perfil da rua" body="Um emblema e até três características. O primeiro da mesa entra como admin." />
      </section>
    </div>
  );
}

function InfoCard({ icon, title, body }: { icon: ReactNode; title: string; body: string }) {
  return (
    <article className="rounded-3xl border border-line bg-surface/80 p-4 backdrop-blur-md">
      <div className="flex items-center gap-2 text-primary">{icon}<h2 className="font-display text-xl uppercase tracking-wide text-fg">{title}</h2></div>
      <p className="mt-2 text-sm text-muted">{body}</p>
    </article>
  );
}

function Desk({ suggestedName }: { suggestedName: string }) {
  const [me, setMe] = useState<Me | null>(null);
  const [posts, setPosts] = useState<FeedPost[]>([]);
  const [stats, setStats] = useState<DeskStats | null>(null);
  const [bootError, setBootError] = useState("");
  const [profileOpen, setProfileOpen] = useState(false);
  const [centralOpen, setCentralOpen] = useState(false);
  const cache = useRef(new Map<number, string>());
  const known = useRef<number[]>([]);
  const seeded = useRef(false);

  const refresh = useCallback(async () => {
    const data = await loadDesk({ data: { knownIds: known.current, suggestedName } });
    const next = data.posts.map((post) => {
      if (post.media) cache.current.set(post.id, post.media);
      return { ...post, media: post.media || cache.current.get(post.id) || "" };
    });
    known.current = next.map((post) => post.id);
    setPosts(next);
    setStats(data.stats);
    setMe(data.me);
    setBootError("");
    if (data.me.needsSetup && !seeded.current) {
      seeded.current = true;
      setProfileOpen(true);
    }
  }, [suggestedName]);

  useEffect(() => {
    let stop = false;
    const tick = async () => {
      if (document.hidden) return;
      try {
        await refresh();
      } catch (error) {
        if (!stop) setBootError(errText(error));
      }
    };
    void tick();
    const id = window.setInterval(() => void tick(), 4000);
    return () => {
      stop = true;
      window.clearInterval(id);
    };
  }, [refresh]);

  if (!me && bootError) {
    return (
      <div className="mt-10 rounded-3xl border border-line bg-surface/85 p-6">
        <h1 className="font-display text-3xl uppercase text-fg">A mesa não respondeu</h1>
        <p className="mt-2 text-sm text-muted">{bootError}</p>
        <button type="button" className={`${primaryBtn} mt-4`} onClick={() => void refresh()}>Tentar de novo</button>
      </div>
    );
  }

  if (!me || !stats) {
    return (
      <div className="mt-10 space-y-3" aria-busy="true">
        <p className="font-display text-4xl uppercase text-fg">Abrindo a mesa…</p>
        <div className="h-28 rounded-3xl border border-line bg-surface/70" />
        <div className="h-64 rounded-3xl border border-line bg-surface/70" />
      </div>
    );
  }

  const locked = me.role === "banido";
  const ready = !me.needsSetup && !locked;

  return (
    <div className="mt-6 grid gap-6 md:grid-cols-[minmax(0,1fr)_18rem]">
      <div className="min-w-0">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <LivePill label="Ao vivo" />
          <div className="flex flex-wrap gap-2">
            {me.role === "admin" && (
              <button type="button" className={primaryBtn} onClick={() => setCentralOpen(true)}>
                <Siren className="size-4" aria-hidden="true" />
                Central
              </button>
            )}
            <button type="button" className={ghostBtn} onClick={() => setProfileOpen(true)}>
              <span aria-hidden="true">{me.emoji}</span>
              {me.displayName}
              {me.role === "admin" && <span className="rounded-full bg-primary px-2 py-0.5 text-xs text-primary-fg">ADM</span>}
            </button>
          </div>
        </div>

        {locked && (
          <div className="mb-4 flex gap-3 rounded-3xl border border-primary/50 bg-surface/85 p-4">
            <Lock className="size-5 shrink-0 text-primary" aria-hidden="true" />
            <p className="text-sm">Sua conta foi bloqueada pelo radar anti-roubo. Dá para olhar a mesa, não para publicar.</p>
          </div>
        )}
        {me.needsSetup && !locked && (
          <div className="mb-4 rounded-3xl border border-line bg-surface/85 p-4">
            <p className="text-sm">Seu perfil ainda está em branco. Escolhe um emblema e as características para publicar e comentar.</p>
            <button type="button" className={`${primaryBtn} mt-3`} onClick={() => setProfileOpen(true)}>Montar perfil</button>
          </div>
        )}
        {ready && <Composer onPublished={() => void refresh()} />}
        <div className="mt-4 space-y-4">
          {posts.length === 0 ? (
            <div className="rounded-3xl border border-dashed border-line bg-surface/70 p-8 text-center">
              <h2 className="font-display text-3xl uppercase text-fg">Nenhum vazamento no ar</h2>
              <p className="mt-2 text-sm text-muted">A espiral está quieta. Publica a primeira imagem ou o primeiro clipe.</p>
            </div>
          ) : (
            posts.map((post) => (
              <PostCard key={post.id} post={post} canTalk={ready} onChanged={() => void refresh()} />
            ))
          )}
        </div>
      </div>
      <aside className="space-y-3 md:sticky md:top-4 md:self-start">
        <RadarPanel stats={stats} me={me} />
      </aside>
      <ProfileDialog me={me} open={profileOpen} onOpenChange={setProfileOpen} onSaved={(next) => setMe(next)} />
      {me.role === "admin" && (
        <CentralDialog open={centralOpen} onOpenChange={setCentralOpen} onChanged={() => void refresh()} />
      )}
    </div>
  );
}

function RadarPanel({ stats, me }: { stats: DeskStats; me: Me }) {
  return (
    <section className="rounded-3xl border border-line bg-surface/85 p-4 backdrop-blur-md">
      <div className="flex items-center gap-2 text-primary">
        <Shield className="size-5" aria-hidden="true" />
        <h2 className="font-display text-xl uppercase tracking-wide text-fg">Anti-roubo</h2>
      </div>
      <p className="mt-2 text-sm text-muted">
        {me.role === "admin"
          ? "Você é o administrador. Libera quarentena, remove golpe e bloqueia conta."
          : "Três denúncias seguram um post. Conteúdo roubado também cai na central."}
      </p>
      <dl className="mt-4 grid grid-cols-2 gap-2 text-sm">
        <Stat label="No ar" value={stats.live} />
        <Stat label="Retidos" value={stats.held} />
        <Stat label="Removidos" value={stats.removed} />
        <Stat label="Agentes" value={stats.members} />
      </dl>
      <p className="mt-4 text-xs font-semibold uppercase tracking-widest text-muted">O radar lê</p>
      <ul className="mt-2 space-y-1 text-sm text-fg">
        {RADAR_LEGEND.map((item) => (
          <li key={item} className="flex gap-2"><span className="text-cyan" aria-hidden="true">+</span>{item}</li>
        ))}
      </ul>
      <p className="mt-4 text-xs text-muted">Confiança {me.trust}/100 · {me.trust >= 80 ? "confiável" : me.trust >= 50 ? "observado" : "frio"}</p>
    </section>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-2xl bg-bg/70 px-3 py-2">
      <dt className="text-xs uppercase tracking-widest text-muted">{label}</dt>
      <dd className="font-display text-2xl tabular-nums text-fg">{value}</dd>
    </div>
  );
}

function Composer({ onPublished }: { onPublished: () => void }) {
  const [caption, setCaption] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<{ url: string; kind: "image" | "video" } | null>(null);
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);
  const radar = scanRadar(caption);

  function take(next: File) {
    setError("");
    setFile(next);
    const url = URL.createObjectURL(next);
    setPreview({ url, kind: next.type.startsWith("video/") ? "video" : "image" });
  }

  async function submit() {
    if (!file || busy) return;
    setBusy(true);
    setError("");
    setInfo("");
    try {
      const media = await prepareMedia(file);
      const result = await publishPost({ data: { caption, media: media.dataUrl, mime: media.mime, kind: media.kind } });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      setCaption("");
      setFile(null);
      setPreview(null);
      setInfo(result.held ? `Radar segurou o post: ${result.flags.join(", ") || "quarentena"}.` : "No ar. A mesa já pode ver.");
      onPublished();
    } catch (caught) {
      setError(errText(caught));
    } finally {
      setBusy(false);
    }
  }

  return (
    <form
      className="rounded-3xl border border-line bg-surface/85 p-4 backdrop-blur-md"
      onSubmit={(event) => {
        event.preventDefault();
        void submit();
      }}
      onDragOver={(event) => event.preventDefault()}
      onDrop={(event) => {
        event.preventDefault();
        const next = event.dataTransfer.files[0];
        if (next) take(next);
      }}
    >
      <div className="flex items-center justify-between gap-3">
        <h2 className="font-display text-2xl uppercase text-fg">Novo vazamento</h2>
        <span className="text-xs uppercase tracking-widest text-muted">{radar.score === 0 ? "limpo" : radar.hits.map((hit) => hit.label).join(" · ")}</span>
      </div>
      <label className="mt-3 block text-sm text-muted" htmlFor="caption">Legenda</label>
      <textarea id="caption" value={caption} maxLength={280} rows={3} onChange={(event) => setCaption(event.target.value)} className={`${field} mt-1 resize-none`} placeholder="O que a cidade mostrou?" />
      {preview?.kind === "image" && <img src={preview.url} alt="" className="mt-3 max-h-96 w-full rounded-2xl object-contain" />}
      {preview?.kind === "video" && <video src={preview.url} className="mt-3 max-h-96 w-full rounded-2xl" controls muted playsInline />}
      <div className="mt-3 flex flex-wrap gap-2">
        <label className={ghostBtn}>
          <ImagePlus className="size-4" aria-hidden="true" />
          Imagem
          <input
            type="file"
            accept="image/jpeg,image/png,image/webp,image/gif"
            className="sr-only"
            onChange={(event) => {
              const next = event.target.files?.[0];
              if (next) take(next);
              event.target.value = "";
            }}
          />
        </label>
        <label className={ghostBtn}>
          <Film className="size-4" aria-hidden="true" />
          Vídeo curto
          <input
            type="file"
            accept="video/mp4,video/webm,video/quicktime"
            className="sr-only"
            onChange={(event) => {
              const next = event.target.files?.[0];
              if (next) take(next);
              event.target.value = "";
            }}
          />
        </label>
        <button type="submit" className={primaryBtn} disabled={!file || busy}>{busy ? "Enviando…" : "Publicar"}</button>
      </div>
      <p className="mt-2 text-xs text-muted">Imagem comprimida na hora. Vídeo até 1,4 MB. O servidor confirma o radar.</p>
      {error && <p className="mt-2 text-sm text-primary">{error}</p>}
      {info && <p className="mt-2 text-sm text-cyan">{info}</p>}
    </form>
  );
}

function PostCard({ post, canTalk, onChanged }: { post: FeedPost; canTalk: boolean; onChanged: () => void }) {
  const [open, setOpen] = useState(false);
  const [reporting, setReporting] = useState(false);
  const [note, setNote] = useState("");
  const verdict = post.status === "held" ? "quarentena" : post.score >= 20 ? "suspeito" : "limpo";

  async function denounce(reason: string) {
    setNote("");
    try {
      const result = await reportTarget({ data: { targetType: "post", targetId: post.id, reason } });
      if (!result.ok) {
        setNote(result.error);
        return;
      }
      setReporting(false);
      setNote(result.queued ? "Três denúncias. O radar segurou o post." : result.duplicate ? "Você já denunciou este." : "Denúncia na central.");
      onChanged();
    } catch (error) {
      setNote(errText(error));
    }
  }

  async function erase() {
    setNote("");
    try {
      const result = await removeOwn({ data: { postId: post.id } });
      if (!result.ok) setNote(result.error);
      else onChanged();
    } catch (error) {
      setNote(errText(error));
    }
  }

  return (
    <article className="overflow-hidden rounded-3xl border border-line bg-surface/88 backdrop-blur-md">
      <div className="flex items-start justify-between gap-3 border-b border-line px-4 py-3">
        <div className="min-w-0">
          <p className="text-xs font-semibold uppercase tracking-widest text-primary">{caseNo(post.id)}</p>
          <p className="mt-1 truncate text-sm">
            <span className="mr-1" aria-hidden="true">{post.author.emoji}</span>
            <span className="font-semibold">{post.author.displayName}</span>
            <span className="text-muted"> @{post.author.handle}</span>
            {post.author.admin && <span className="ml-2 rounded-full bg-primary px-2 py-0.5 text-xs font-semibold text-primary-fg">ADM</span>}
          </p>
          {post.author.traits.length > 0 && (
            <p className="mt-1 text-xs text-muted">{post.author.traits.map(traitLabel).join(" · ")}</p>
          )}
        </div>
        <div className="text-right">
          <p className="text-xs text-muted">{ago(post.createdAt)}</p>
          <p className={`mt-1 text-xs font-semibold uppercase tracking-widest ${verdict === "limpo" ? "text-cyan" : "text-primary"}`}>{verdict}</p>
        </div>
      </div>
      {post.kind === "video" ? (
        <video src={post.media} className="max-h-screen w-full bg-bg object-contain" controls playsInline preload="metadata" />
      ) : (
        <img src={post.media} alt="" className="max-h-screen w-full bg-bg object-contain" />
      )}
      <div className="space-y-3 px-4 py-3">
        {post.caption && <p className="break-words text-sm">{post.caption}</p>}
        {post.status === "held" && <p className="text-sm text-primary">Na quarentena. Só você e o admin veem até liberar.</p>}
        {post.flags.length > 0 && post.status !== "held" && (
          <p className="text-sm text-primary">Radar: {post.flags.join(", ")}. Não pague e não mande senha.</p>
        )}
        <div className="flex flex-wrap gap-2">
          <button type="button" className={ghostBtn} onClick={() => setOpen((value) => !value)} aria-expanded={open}>
            <MessageCircle className="size-4" aria-hidden="true" />
            {post.commentCount} ao vivo
          </button>
          {!post.mine && (
            <button type="button" className={ghostBtn} onClick={() => setReporting((value) => !value)}>Denunciar</button>
          )}
          {post.mine && (
            <button type="button" className={ghostBtn} onClick={() => void erase()}>
              <Trash2 className="size-4" aria-hidden="true" />
              Apagar
            </button>
          )}
        </div>
        {reporting && (
          <div className="flex flex-wrap gap-2">
            {REPORT_REASONS.map((reason) => (
              <button key={reason} type="button" className={ghostBtn} onClick={() => void denounce(reason)}>{reason}</button>
            ))}
          </div>
        )}
        {note && <p className="text-sm text-cyan">{note}</p>}
        {open && <Thread postId={post.id} canTalk={canTalk} />}
      </div>
    </article>
  );
}

function Thread({ postId, canTalk }: { postId: number; canTalk: boolean }) {
  const [comments, setComments] = useState<ThreadComment[]>([]);
  const [body, setBody] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);

  const pull = useCallback(async () => {
    const result = await loadThread({ data: { postId } });
    setComments(result.comments);
  }, [postId]);

  useEffect(() => {
    let stop = false;
    const tick = async () => {
      if (document.hidden) return;
      try {
        const result = await loadThread({ data: { postId } });
        if (!stop) setComments(result.comments);
      } catch {
        /* next tick retries */
      }
    };
    void tick();
    const id = window.setInterval(() => void tick(), 2500);
    return () => {
      stop = true;
      window.clearInterval(id);
    };
  }, [postId]);

  async function send() {
    if (busy) return;
    setBusy(true);
    setNote("");
    try {
      const result = await addComment({ data: { postId, body } });
      if (!result.ok) {
        setNote(result.error);
        return;
      }
      setBody("");
      setNote(result.held ? `Comentário retido: ${result.flags.join(", ")}.` : "Entrou. Quem está aqui já vê.");
      await pull();
    } catch (error) {
      setNote(errText(error));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="rounded-2xl bg-bg/65 p-3">
      <p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-cyan">
        <span className="live-dot h-2 w-2 rounded-full bg-cyan" aria-hidden="true" />
        Comentários ao vivo
      </p>
      <ul className="mt-3 space-y-3">
        {comments.length === 0 && <li className="text-sm text-muted">Ninguém falou ainda. A thread atualiza sozinha.</li>}
        {comments.map((comment) => (
          <li key={comment.id} className="text-sm">
            <p>
              <span aria-hidden="true">{comment.author.emoji} </span>
              <span className="font-semibold">{comment.author.displayName}</span>
              <span className="text-muted"> @{comment.author.handle}</span>
              {comment.author.admin && <span className="ml-2 text-xs font-semibold text-primary">ADM</span>}
              <span className="ml-2 text-xs text-muted">{ago(comment.createdAt)}</span>
            </p>
            <p className="mt-1 break-words">{comment.body}</p>
            {comment.status === "held" && <p className="text-xs text-primary">Retido pelo radar. Os outros não veem.</p>}
          </li>
        ))}
      </ul>
      {canTalk ? (
        <form
          className="mt-3 flex gap-2"
          onSubmit={(event) => {
            event.preventDefault();
            void send();
          }}
        >
          <label className="sr-only" htmlFor={`comment-${postId}`}>Comentário</label>
          <input
            id={`comment-${postId}`}
            value={body}
            maxLength={400}
            onChange={(event) => setBody(event.target.value)}
            className={field}
            placeholder="Fala na mesa"
          />
          <button type="submit" className={primaryBtn} disabled={busy || body.trim().length === 0} aria-label="Enviar comentário">
            <Send className="size-4" aria-hidden="true" />
          </button>
        </form>
      ) : (
        <p className="mt-3 text-sm text-muted">Monta teu perfil para comentar.</p>
      )}
      {note && <p className="mt-2 text-sm text-cyan">{note}</p>}
    </div>
  );
}

function ProfileDialog({
  me,
  open,
  onOpenChange,
  onSaved,
}: {
  me: Me;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSaved: (me: Me) => void;
}) {
  const [handle, setHandle] = useState(me.handle);
  const [displayName, setDisplayName] = useState(me.displayName);
  const [bio, setBio] = useState(me.bio);
  const [emoji, setEmoji] = useState(me.emoji);
  const [traits, setTraits] = useState<string[]>(me.traits);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const wasOpen = useRef(false);

  useEffect(() => {
    if (open && !wasOpen.current) {
      setHandle(me.handle);
      setDisplayName(me.displayName);
      setBio(me.bio);
      setEmoji(me.emoji);
      setTraits(me.traits);
      setError("");
    }
    wasOpen.current = open;
  }, [open, me]);

  function toggle(id: string) {
    setTraits((current) => {
      if (current.includes(id)) return current.filter((item) => item !== id);
      if (current.length >= 3) return current;
      return [...current, id];
    });
  }

  async function save() {
    setBusy(true);
    setError("");
    try {
      const result = await saveProfile({ data: { handle, displayName, bio, emoji, traits } });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      onSaved(result.me);
      onOpenChange(false);
    } catch (caught) {
      setError(errText(caught));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog.Root open={open} onOpenChange={onOpenChange}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-40 bg-bg/75 backdrop-blur-sm" />
        <Dialog.Content className="fixed inset-x-0 bottom-0 z-50 max-h-dvh overflow-y-auto rounded-t-3xl border border-line bg-surface p-5 md:inset-auto md:left-1/2 md:top-1/2 md:w-full md:max-w-lg md:-translate-x-1/2 md:-translate-y-1/2 md:rounded-3xl">
          <div className="flex items-start justify-between gap-3">
            <div>
              <Dialog.Title className="font-display text-3xl uppercase text-fg">Teu perfil</Dialog.Title>
              <Dialog.Description className="mt-1 text-sm text-muted">
                {me.role === "admin"
                  ? "Esta mesa é sua. Você é o administrador do radar."
                  : "Um emblema e até três características. É assim que a mesa te vê."}
              </Dialog.Description>
            </div>
            <Dialog.Close className={ghostBtn} aria-label="Fechar">
              <X className="size-4" aria-hidden="true" />
            </Dialog.Close>
          </div>
          <label className="mt-4 block text-sm text-muted" htmlFor="display-name">Nome</label>
          <input id="display-name" value={displayName} maxLength={32} onChange={(event) => setDisplayName(event.target.value)} className={`${field} mt-1`} />
          <label className="mt-3 block text-sm text-muted" htmlFor="handle">Arroba</label>
          <input id="handle" value={handle} maxLength={16} onChange={(event) => setHandle(event.target.value.toLowerCase())} className={`${field} mt-1`} />
          <label className="mt-3 block text-sm text-muted" htmlFor="bio">Bio</label>
          <textarea id="bio" value={bio} maxLength={160} rows={3} onChange={(event) => setBio(event.target.value)} className={`${field} mt-1 resize-none`} />
          <p className="mt-4 text-xs font-semibold uppercase tracking-widest text-muted">Emblema</p>
          <div className="mt-2 grid grid-cols-4 gap-2">
            {MARKS.map((mark) => (
              <button
                key={mark.id}
                type="button"
                onClick={() => setEmoji(mark.emoji)}
                aria-pressed={emoji === mark.emoji}
                className={`min-h-16 rounded-2xl border px-2 py-2 text-center text-xs ${emoji === mark.emoji ? "border-primary bg-primary/15 text-fg" : "border-line text-muted"}`}
              >
                <span className="block text-xl" aria-hidden="true">{mark.emoji}</span>
                {mark.label}
              </button>
            ))}
          </div>
          <p className="mt-4 text-xs font-semibold uppercase tracking-widest text-muted">Características · {traits.length}/3</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {TRAITS.map((trait) => {
              const on = traits.includes(trait.id);
              return (
                <button key={trait.id} type="button" aria-pressed={on} onClick={() => toggle(trait.id)} className={on ? primaryBtn : ghostBtn}>
                  {trait.label}
                </button>
              );
            })}
          </div>
          {error && <p className="mt-3 text-sm text-primary">{error}</p>}
          <button type="button" className={`${primaryBtn} mt-4 w-full`} disabled={busy} onClick={() => void save()}>
            {busy ? "Salvando…" : "Salvar perfil"}
          </button>
          <div className="mt-4">
            <UserButton />
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}

function CentralDialog({
  open,
  onOpenChange,
  onChanged,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onChanged: () => void;
}) {
  const [held, setHeld] = useState<FeedPost[]>([]);
  const [reports, setReports] = useState<ReportRow[]>([]);
  const [members, setMembers] = useState<MemberRow[]>([]);
  const [error, setError] = useState("");
  const cache = useRef(new Map<number, string>());
  const known = useRef<number[]>([]);

  const pull = useCallback(async () => {
    const result = await loadCentral({ data: { knownIds: known.current } });
    if (!result.ok) {
      setError(result.error);
      return;
    }
    const next = result.held.map((post) => {
      if (post.media) cache.current.set(post.id, post.media);
      return { ...post, media: post.media || cache.current.get(post.id) || "" };
    });
    known.current = next.map((post) => post.id);
    setHeld(next);
    setReports(result.reports);
    setMembers(result.members);
    setError("");
  }, []);

  useEffect(() => {
    if (!open) return;
    let stop = false;
    const tick = async () => {
      try {
        await pull();
      } catch (caught) {
        if (!stop) setError(errText(caught));
      }
    };
    void tick();
    const id = window.setInterval(() => void tick(), 4000);
    return () => {
      stop = true;
      window.clearInterval(id);
    };
  }, [open, pull]);

  async function act(
    input:
      | { action: "release"; postId: number }
      | { action: "remove"; postId: number }
      | { action: "ban"; userId: string }
      | { action: "unban"; userId: string }
      | { action: "dismiss"; reportId: number },
  ) {
    setError("");
    try {
      const result = await moderate({ data: input });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      await pull();
      onChanged();
    } catch (caught) {
      setError(errText(caught));
    }
  }

  return (
    <Dialog.Root open={open} onOpenChange={onOpenChange}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-40 bg-bg/75 backdrop-blur-sm" />
        <Dialog.Content className="fixed inset-x-0 bottom-0 z-50 max-h-dvh overflow-y-auto rounded-t-3xl border border-line bg-surface p-5 md:inset-auto md:left-1/2 md:top-1/2 md:w-full md:max-w-2xl md:-translate-x-1/2 md:-translate-y-1/2 md:rounded-3xl">
          <div className="flex items-start justify-between gap-3">
            <div>
              <Dialog.Title className="font-display text-3xl uppercase text-fg">Central do radar</Dialog.Title>
              <Dialog.Description className="mt-1 text-sm text-muted">Quarentena, denúncias e contas. Só o admin vê isto.</Dialog.Description>
            </div>
            <Dialog.Close className={ghostBtn} aria-label="Fechar">
              <X className="size-4" aria-hidden="true" />
            </Dialog.Close>
          </div>
          {error && <p className="mt-3 text-sm text-primary">{error}</p>}
          <h3 className="mt-5 font-display text-xl uppercase text-fg">Quarentena</h3>
          {held.length === 0 && <p className="mt-2 text-sm text-muted">Nada retido agora.</p>}
          <ul className="mt-2 space-y-3">
            {held.map((post) => (
              <li key={post.id} className="rounded-2xl border border-line p-3">
                <p className="text-sm font-semibold">{caseNo(post.id)} · @{post.author.handle}</p>
                <p className="text-sm text-muted">{post.caption || "Sem legenda"} · {post.flags.join(", ") || "denúncia"}</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  <button type="button" className={primaryBtn} onClick={() => void act({ action: "release", postId: post.id })}>Liberar</button>
                  <button type="button" className={ghostBtn} onClick={() => void act({ action: "remove", postId: post.id })}>Remover</button>
                </div>
              </li>
            ))}
          </ul>
          <h3 className="mt-5 font-display text-xl uppercase text-fg">Denúncias</h3>
          {reports.length === 0 && <p className="mt-2 text-sm text-muted">Nenhuma denúncia aberta.</p>}
          <ul className="mt-2 space-y-2">
            {reports.map((report) => (
              <li key={report.id} className="flex flex-wrap items-center justify-between gap-2 rounded-2xl bg-bg/60 px-3 py-2 text-sm">
                <span>@{report.reporterHandle} · {report.reason} · {report.targetType} {report.targetId}</span>
                <button type="button" className={ghostBtn} onClick={() => void act({ action: "dismiss", reportId: report.id })}>Arquivar</button>
              </li>
            ))}
          </ul>
          <h3 className="mt-5 font-display text-xl uppercase text-fg">Agentes</h3>
          <ul className="mt-2 space-y-2">
            {members.map((member) => (
              <li key={member.userId} className="flex flex-wrap items-center justify-between gap-2 rounded-2xl bg-bg/60 px-3 py-2 text-sm">
                <span>
                  <span aria-hidden="true">{member.emoji} </span>
                  {member.displayName} @{member.handle} · {member.role} · {member.trust}
                </span>
                {member.role === "membro" && (
                  <button type="button" className={ghostBtn} onClick={() => void act({ action: "ban", userId: member.userId })}>Bloquear</button>
                )}
                {member.role === "banido" && (
                  <button type="button" className={ghostBtn} onClick={() => void act({ action: "unban", userId: member.userId })}>Desbloquear</button>
                )}
              </li>
            ))}
          </ul>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
