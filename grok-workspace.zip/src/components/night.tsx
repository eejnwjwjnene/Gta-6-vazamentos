export function NightBackdrop() {
  return (
    <>
      <video
        className="bg-spiral pointer-events-none fixed inset-0 h-full w-full object-cover"
        autoPlay
        muted
        loop
        playsInline
        preload="auto"
        aria-hidden="true"
      >
        <source src="/media/spiral.mp4" type="video/mp4" />
      </video>
      <div className="veil" aria-hidden="true" />
    </>
  );
}
