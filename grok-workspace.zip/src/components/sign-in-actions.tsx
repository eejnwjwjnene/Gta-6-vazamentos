import { GROK_PROVIDERS, signIn } from "@/lib/auth/client";

const primary =
  "inline-flex min-h-11 items-center justify-center rounded-full bg-primary px-5 text-sm font-semibold text-primary-fg transition-colors duration-200 hover:bg-primary/90 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary";
const ghost =
  "inline-flex min-h-11 items-center justify-center rounded-full border border-line bg-surface/80 px-5 text-sm font-semibold text-fg transition-colors duration-200 hover:border-primary/70 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary";

export function SignInActions() {
  return (
    <div className="flex flex-col gap-2 sm:flex-row">
      {GROK_PROVIDERS.map((provider, index) => (
        <button
          key={provider.providerId}
          type="button"
          onClick={() => signIn(provider.providerId, { callbackURL: "/" })}
          className={index === 0 ? primary : ghost}
        >
          Entrar com {provider.label}
        </button>
      ))}
    </div>
  );
}
